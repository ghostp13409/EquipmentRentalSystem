namespace Midterm_EquipmentRental_Group2.DTOs
{
    public class ExtendRentalRequest
    {
        public DateTime NewDueDate { get; set; }
        public string Reason { get; set; }
    }
}